import Cocoa

var text = "hiii";
//dictionary of existing words in a particular language
var dictionary = Set<String>();
dictionary.insert("hi");

//This function takes a string which is the text to be tokenized and a set of
//strings which is a dictioary as arguments and returns an array strings which
//are tokens. If the text contains an unknown word, the function add the smallest
//element to the array and moves on.
//This algorithm works the best for Chinese text.
func tokenize(_ text: inout String, _ dictionary: inout Set<String>) -> [String] {
    var tokens = [String]();
    var index = text.endIndex;
    var token = "";
    
    while(!text.isEmpty){
        token = String(text[..<index]);
        
        if dictionary.contains(token) || token.count == 1 {
            tokens.append(token);
            text = (index == text.endIndex) ? "" : String(text[index...]);
            index = text.endIndex;
        } else {
            index = text.index(before: index);

        }
    }
    return tokens;
}

let tokens = tokenize(&text, &dictionary);

print(tokens);

